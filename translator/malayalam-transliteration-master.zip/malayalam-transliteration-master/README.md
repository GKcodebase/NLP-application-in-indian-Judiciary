# malayalam-transliteration 
a simple Transliteration program in python for malayalam (converts njaan to ഞാൻ )

this is **not a translation program**. it is a program to convert words based on related sound in 

# How to use
  * download or clone the repository.
  * run main.py wait for it to finish creating database (to avoid recreating the db over and over again comment out the lines)
  * The type word in prompt to get tansliteration
  
# How it works
The program makes up a database of possible english typings of a malayalam word
and then for each user input it tries to find a near match in the database and along with that 
tries to create the original word


# To Do
  1. improove tokenizing
  
  2. use a better method to remove noise
  
  3. improove learning algorithm
  
  <p align="center">😎😘</p>
